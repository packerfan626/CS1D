/*********************************************************
 *  AUTHOR       : Dori J. Mouawad
 *  Assignment#7 : Heaps
 *  CLASS	     : CS1D
 *  SECTION      : TTH: 5:30-9:20pm
 *  Due Date     : 3/10/2015
 *********************************************************/

#ifndef HEADER_H_
#define HEADER_H_

#include <iostream>
#include <iomanip>

using namespace std;

#include "heap.h"

#endif /* HEADER_H_ */
